package models;

public class Pawn extends Piece{
    @Override
    public int[][] move(int place) {
        return super.move(place);
    }
}
