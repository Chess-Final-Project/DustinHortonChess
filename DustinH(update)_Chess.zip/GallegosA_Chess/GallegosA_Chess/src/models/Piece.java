package models;

public abstract class Piece {
    private Board board;

    public Board getBoard() {
        return board;
    }

    public int[][] move(int place) {

    }
}
