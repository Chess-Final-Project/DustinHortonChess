package models;

public class Bishop extends Piece {
    Position spot;
    @Override
    public int[][] move(int start) {
        if(spot.getRows() - start.getRows() == spot.getCols() - start.getCols()) {

        }
    }
}
