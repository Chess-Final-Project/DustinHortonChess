package models;

public class Queen extends Piece {
    @Override
    public int[][] move(int start) {

    }
}
