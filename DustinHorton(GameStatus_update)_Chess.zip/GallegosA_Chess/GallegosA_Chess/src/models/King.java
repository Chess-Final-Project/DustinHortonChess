package models;

public class King extends Piece {
    @Override
    public int[][] move(int place) {
        return super.move(place);
    }
}
