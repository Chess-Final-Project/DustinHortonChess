package models;

public enum Color {
    WHITE,
    BLACK
}
