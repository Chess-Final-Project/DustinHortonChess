package models;

public class Bishop extends Piece {
    @Override
    public int[][] move(int place) {
        return super.move(place);
    }
}
