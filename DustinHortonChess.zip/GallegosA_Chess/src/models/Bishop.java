package models;

public class Bishop extends Piece {
    Position spot;
    @Override
    public int[][] move(Position start) {
        if(spot.getRows() - start.getRows() == spot.getCols() - start.getCols()) {

        }
    }
}
