package models;

public class Queen extends Piece {
    @Override
    public int[][] move(Position start) {

    }
}
