package models;

public class King extends Piece {
    @Override
    public int[][] move(Position start) {

    }
}
